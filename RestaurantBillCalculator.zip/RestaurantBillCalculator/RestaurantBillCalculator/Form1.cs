﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantBillCalculator
{
    public partial class frmRestaurantBill : Form
    {
        double beveragePrice;
        double appetizerPrice;
        double mainCoursePrice;
        double dessertPrice;

        public frmRestaurantBill()
        {
            InitializeComponent();
        }

        private void frmRestaurantBill_Load(object sender, EventArgs e)
        {
            

            
            
        }

        private void BeveragesCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (BeveragesCB.Text)
            {
                case "Soda":
                    beveragePrice = 1.95;
                    break;
                case "Tea":
                    beveragePrice = 1.50;
                    break;
                case "Coffee":
                    beveragePrice = 1.25;
                    break;
                case "Mineral Water":
                    beveragePrice = 2.95;
                    break;
                case "Juice":
                    beveragePrice = 2.50;
                    break;
                case "Milk":
                    beveragePrice = 1.50;
                    break;
                default:
                    break;
            }

            lblBeveragePrice.Text = string.Format("Price: {0:C}", beveragePrice);


        }

        private void AppetizersCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (AppetizersCB.Text)
            {
                case "Buffalo Wings":
                    appetizerPrice = 5.95;
                    break;
                case "Chicken Fingers":
                    appetizerPrice = 6.95;
                    break;
                case "Potato Skins":
                    appetizerPrice = 8.95;
                    break;
                case "Nachos":
                    appetizerPrice = 8.95;
                    break;
                case "Mushroom caps":
                    appetizerPrice = 10.95;
                    break;
                case "Shrimp Cocktail":
                    appetizerPrice = 12.95;
                    break;
                case "Chips and Salsa":
                    appetizerPrice = 6.95;
                    break;
                default:
                    break;
            }

            lblAppetizerPrice.Text = string.Format("Price: {0:C}", appetizerPrice);

        }

        private void MainCourseCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (MainCourseCB.Text)
            {
                case "Seafood Alfredo":
                    mainCoursePrice = 15.95;
                    break;
                case "Chicken Alfredo":
                    mainCoursePrice = 13.95;
                    break;
                case "Chicken Picatta":
                    mainCoursePrice = 13.95;
                    break;
                case "Turkey Club":
                    mainCoursePrice = 11.95;
                    break;
                case "Lobster Pie":
                    mainCoursePrice = 19.95;
                    break;
                case "Prime Rib":
                    mainCoursePrice = 20.95;
                    break;
                case "Shrimp Scampi":
                    mainCoursePrice = 18.95;
                    break;
                case "Turkey Dinner":
                    mainCoursePrice = 13.95;
                    break;
                case "Stuffed Chicken":
                    mainCoursePrice = 14.95;
                    break;
                default:
                    break;
            }

            lblMainCoursePrice.Text = string.Format("Price: {0:C}", mainCoursePrice);
        }

        private void DessertsCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (DessertsCB.Text)
            {
                case "Apple Pie":
                    dessertPrice = 5.95;
                    break;
                case "Sundae":
                    dessertPrice = 3.95;
                    break;
                case "Carrot Cake":
                    dessertPrice = 5.95;
                    break;
                case "Mud Pie":
                    dessertPrice = 4.95;
                    break;
                case "Apple Crisp":
                    dessertPrice = 5.95;
                    break;
                case "Chocolate Lava Cake":
                    dessertPrice = 5.95;
                    break;
                default:
                    break;
            }
            lblDessertPrice.Text = string.Format("Price: {0:C}", dessertPrice);
        }

        private void btnComplete_Click(object sender, EventArgs e)
        {
            double subTotal = beveragePrice + appetizerPrice + mainCoursePrice + dessertPrice;
            double tax = 0.045 * subTotal;
            double total = subTotal + tax;

            lblSubtotal.Text = string.Format("Subtotal: {0:C}", subTotal);
            lblTax.Text = string.Format("Tax: {0:C}", tax);
            lblTotal.Text = string.Format("Total: {0:C}", total);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblSubtotal.Text = string.Format("Subtotal: {0:C}", 0);
            lblTax.Text = string.Format("Tax: {0:C}", 0);
            lblTotal.Text = string.Format("Total: {0:C}", 0);
        }
    }
}
