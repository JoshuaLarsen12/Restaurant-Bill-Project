﻿namespace RestaurantBillCalculator
{
    partial class frmRestaurantBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBeverages = new System.Windows.Forms.Label();
            this.BeveragesCB = new System.Windows.Forms.ComboBox();
            this.lblAppetizers = new System.Windows.Forms.Label();
            this.AppetizersCB = new System.Windows.Forms.ComboBox();
            this.lblMainCourse = new System.Windows.Forms.Label();
            this.MainCourseCB = new System.Windows.Forms.ComboBox();
            this.lblDesserts = new System.Windows.Forms.Label();
            this.DessertsCB = new System.Windows.Forms.ComboBox();
            this.lblBeveragePrice = new System.Windows.Forms.Label();
            this.lblAppetizerPrice = new System.Windows.Forms.Label();
            this.lblMainCoursePrice = new System.Windows.Forms.Label();
            this.lblDessertPrice = new System.Windows.Forms.Label();
            this.btnComplete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBeverages
            // 
            this.lblBeverages.AutoSize = true;
            this.lblBeverages.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeverages.Location = new System.Drawing.Point(12, 9);
            this.lblBeverages.Name = "lblBeverages";
            this.lblBeverages.Size = new System.Drawing.Size(85, 20);
            this.lblBeverages.TabIndex = 0;
            this.lblBeverages.Text = "Beverages";
            // 
            // BeveragesCB
            // 
            this.BeveragesCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BeveragesCB.FormattingEnabled = true;
            this.BeveragesCB.Items.AddRange(new object[] {
            "Soda",
            "Tea",
            "Coffee",
            "Mineral Water",
            "Juice",
            "Milk"});
            this.BeveragesCB.Location = new System.Drawing.Point(116, 11);
            this.BeveragesCB.Name = "BeveragesCB";
            this.BeveragesCB.Size = new System.Drawing.Size(129, 21);
            this.BeveragesCB.TabIndex = 1;
            this.BeveragesCB.SelectedIndexChanged += new System.EventHandler(this.BeveragesCB_SelectedIndexChanged);
            // 
            // lblAppetizers
            // 
            this.lblAppetizers.AutoSize = true;
            this.lblAppetizers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppetizers.Location = new System.Drawing.Point(12, 54);
            this.lblAppetizers.Name = "lblAppetizers";
            this.lblAppetizers.Size = new System.Drawing.Size(85, 20);
            this.lblAppetizers.TabIndex = 2;
            this.lblAppetizers.Text = "Appetizers";
            // 
            // AppetizersCB
            // 
            this.AppetizersCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AppetizersCB.FormattingEnabled = true;
            this.AppetizersCB.Items.AddRange(new object[] {
            "Buffalo Wings",
            "Chicken Fingers",
            "Potato Skins",
            "Nachos",
            "Mushroom caps",
            "Shrimp Cocktail",
            "Chips and Salsa"});
            this.AppetizersCB.Location = new System.Drawing.Point(116, 53);
            this.AppetizersCB.Name = "AppetizersCB";
            this.AppetizersCB.Size = new System.Drawing.Size(129, 21);
            this.AppetizersCB.TabIndex = 3;
            this.AppetizersCB.SelectedIndexChanged += new System.EventHandler(this.AppetizersCB_SelectedIndexChanged);
            // 
            // lblMainCourse
            // 
            this.lblMainCourse.AutoSize = true;
            this.lblMainCourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainCourse.Location = new System.Drawing.Point(12, 98);
            this.lblMainCourse.Name = "lblMainCourse";
            this.lblMainCourse.Size = new System.Drawing.Size(98, 20);
            this.lblMainCourse.TabIndex = 4;
            this.lblMainCourse.Text = "Main Course";
            // 
            // MainCourseCB
            // 
            this.MainCourseCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MainCourseCB.FormattingEnabled = true;
            this.MainCourseCB.Items.AddRange(new object[] {
            "Seafood Alfredo",
            "Chicken Alfredo",
            "Chicken Picatta",
            "Turkey Club",
            "Lobster Pie",
            "Prime Rib",
            "Shrimp Scampi",
            "Turkey Dinner",
            "Stuffed Chicken"});
            this.MainCourseCB.Location = new System.Drawing.Point(116, 97);
            this.MainCourseCB.Name = "MainCourseCB";
            this.MainCourseCB.Size = new System.Drawing.Size(129, 21);
            this.MainCourseCB.TabIndex = 5;
            this.MainCourseCB.SelectedIndexChanged += new System.EventHandler(this.MainCourseCB_SelectedIndexChanged);
            // 
            // lblDesserts
            // 
            this.lblDesserts.AutoSize = true;
            this.lblDesserts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesserts.Location = new System.Drawing.Point(12, 136);
            this.lblDesserts.Name = "lblDesserts";
            this.lblDesserts.Size = new System.Drawing.Size(73, 20);
            this.lblDesserts.TabIndex = 6;
            this.lblDesserts.Text = "Desserts";
            // 
            // DessertsCB
            // 
            this.DessertsCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DessertsCB.FormattingEnabled = true;
            this.DessertsCB.Items.AddRange(new object[] {
            "Apple Pie",
            "Sundae",
            "Carrot Cake",
            "Mud Pie",
            "Apple Crisp",
            "Chocolate Lava Cake"});
            this.DessertsCB.Location = new System.Drawing.Point(116, 135);
            this.DessertsCB.Name = "DessertsCB";
            this.DessertsCB.Size = new System.Drawing.Size(129, 21);
            this.DessertsCB.TabIndex = 7;
            this.DessertsCB.SelectedIndexChanged += new System.EventHandler(this.DessertsCB_SelectedIndexChanged);
            // 
            // lblBeveragePrice
            // 
            this.lblBeveragePrice.AutoSize = true;
            this.lblBeveragePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeveragePrice.Location = new System.Drawing.Point(251, 12);
            this.lblBeveragePrice.Name = "lblBeveragePrice";
            this.lblBeveragePrice.Size = new System.Drawing.Size(92, 20);
            this.lblBeveragePrice.TabIndex = 8;
            this.lblBeveragePrice.Text = "Price: $0.00";
            // 
            // lblAppetizerPrice
            // 
            this.lblAppetizerPrice.AutoSize = true;
            this.lblAppetizerPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppetizerPrice.Location = new System.Drawing.Point(251, 54);
            this.lblAppetizerPrice.Name = "lblAppetizerPrice";
            this.lblAppetizerPrice.Size = new System.Drawing.Size(92, 20);
            this.lblAppetizerPrice.TabIndex = 8;
            this.lblAppetizerPrice.Text = "Price: $0.00";
            // 
            // lblMainCoursePrice
            // 
            this.lblMainCoursePrice.AutoSize = true;
            this.lblMainCoursePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainCoursePrice.Location = new System.Drawing.Point(251, 97);
            this.lblMainCoursePrice.Name = "lblMainCoursePrice";
            this.lblMainCoursePrice.Size = new System.Drawing.Size(92, 20);
            this.lblMainCoursePrice.TabIndex = 8;
            this.lblMainCoursePrice.Text = "Price: $0.00";
            // 
            // lblDessertPrice
            // 
            this.lblDessertPrice.AutoSize = true;
            this.lblDessertPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDessertPrice.Location = new System.Drawing.Point(251, 136);
            this.lblDessertPrice.Name = "lblDessertPrice";
            this.lblDessertPrice.Size = new System.Drawing.Size(92, 20);
            this.lblDessertPrice.TabIndex = 8;
            this.lblDessertPrice.Text = "Price: $0.00";
            // 
            // btnComplete
            // 
            this.btnComplete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComplete.Location = new System.Drawing.Point(135, 172);
            this.btnComplete.Name = "btnComplete";
            this.btnComplete.Size = new System.Drawing.Size(89, 33);
            this.btnComplete.TabIndex = 9;
            this.btnComplete.Text = "Complete";
            this.btnComplete.UseVisualStyleBackColor = true;
            this.btnComplete.Click += new System.EventHandler(this.btnComplete_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblTotal);
            this.panel1.Controls.Add(this.lblTax);
            this.panel1.Controls.Add(this.lblSubtotal);
            this.panel1.Location = new System.Drawing.Point(104, 211);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(152, 134);
            this.panel1.TabIndex = 10;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(34, 89);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(106, 24);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "Total: $0.00";
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.Location = new System.Drawing.Point(58, 54);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(82, 20);
            this.lblTax.TabIndex = 1;
            this.lblTax.Text = "Tax: $0.00";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.AutoSize = true;
            this.lblSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtotal.Location = new System.Drawing.Point(23, 11);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(117, 20);
            this.lblSubtotal.TabIndex = 0;
            this.lblSubtotal.Text = "Subtotal: $0.00";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(135, 351);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(89, 23);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmRestaurantBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 393);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnComplete);
            this.Controls.Add(this.lblDessertPrice);
            this.Controls.Add(this.lblMainCoursePrice);
            this.Controls.Add(this.lblAppetizerPrice);
            this.Controls.Add(this.lblBeveragePrice);
            this.Controls.Add(this.DessertsCB);
            this.Controls.Add(this.lblDesserts);
            this.Controls.Add(this.MainCourseCB);
            this.Controls.Add(this.lblMainCourse);
            this.Controls.Add(this.AppetizersCB);
            this.Controls.Add(this.lblAppetizers);
            this.Controls.Add(this.BeveragesCB);
            this.Controls.Add(this.lblBeverages);
            this.Name = "frmRestaurantBill";
            this.Text = "Restaurant Bill";
            this.Load += new System.EventHandler(this.frmRestaurantBill_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBeverages;
        private System.Windows.Forms.ComboBox BeveragesCB;
        private System.Windows.Forms.Label lblAppetizers;
        private System.Windows.Forms.ComboBox AppetizersCB;
        private System.Windows.Forms.Label lblMainCourse;
        private System.Windows.Forms.ComboBox MainCourseCB;
        private System.Windows.Forms.Label lblDesserts;
        private System.Windows.Forms.ComboBox DessertsCB;
        private System.Windows.Forms.Label lblBeveragePrice;
        private System.Windows.Forms.Label lblAppetizerPrice;
        private System.Windows.Forms.Label lblMainCoursePrice;
        private System.Windows.Forms.Label lblDessertPrice;
        private System.Windows.Forms.Button btnComplete;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblSubtotal;
        private System.Windows.Forms.Button btnClear;
    }
}

